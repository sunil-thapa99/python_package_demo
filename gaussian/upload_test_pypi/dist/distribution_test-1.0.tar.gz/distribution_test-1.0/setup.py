from setuptools import setup

setup(name='distribution_test',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['distribution_test'],
      author='Sunil Thapa',
      author_email='sunil43thapa@gmail.com',
      zip_safe=False)

